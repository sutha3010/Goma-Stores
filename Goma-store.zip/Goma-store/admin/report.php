<?php
session_start();
include("../db.php");
if(isset($_GET['action']) && $_GET['action']!="" && $_GET['action']=='delete')
{
$user_id=$_GET['user_id'];

/*this is delet quer*/
mysqli_query($con,"delete from user_info where user_id='$user_id'")or die("query is incorrect...");
}

include "sidenav.php";
include "topheader.php";
?>

<div class="content">
        <div class="container-fluid">
          <!-- your content here -->
          <div class="col-md-14">
            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title">Orders  / Page </h4>
              </div>
              <div class="card-body">
                <div class="table-responsive ps">
                  <table class="table table-hover tablesorter " id="">
                    <thead class=" text-primary">
                      <tr><th>Products Name</th><th>Total Count</th>
                    </tr></thead>
                    <tbody>
                  
                       

<?php 
                        // $result=mysqli_query($con,"select order_id, product_title, first_name, mobile, email, address1, address2, product_price,address2, qty from orders,products,user_info where orders.product_id=products.product_id and user_info.user_id=orders.user_id Limit $page1,10")
                        // or die ("query 1 incorrect.....");
                        $sql3 ="SELECT * FROM `products`";
                        $res3 =mysqli_query($con,$sql3);
                        while($row2 = mysqli_fetch_array($res3)){

                                $pid=$row2['product_id'];

                                $sql4 ="SELECT * FROM `cart` where p_id = $pid";
                                $res4 =mysqli_query($con,$sql4);
                                $no_of_product = mysqli_num_rows($res4);

                                if($no_of_product > 0){
                                while($row4 = mysqli_fetch_array($res4)){
                                       
                                         
                                     $sql2 = "SELECT SUM(qty) as total FROM cart ";
                                     $res2 =mysqli_query($con,$sql2);
                                     while($count = mysqli_fetch_array($res2)){
                                      $pid = $count['p_id'];

                                    
                                  ?>
                                          <tr>
                                           
                                            <td><?php echo $row2['product_title']; ?></td>
                                            <td><?php echo $count['total']; ?></td>
                                </tr>

                                  <?php
                                      }
                                     

                                }
                              }
                       
                        

                                
                       
                        ?>
                    </tbody>
                  </table>
                  
                <div class="ps__rail-x" style="left: 0px; bottom: 0px;"><div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__rail-y" style="top: 0px; right: 0px;"><div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 0px;"></div></div></div>
              </div>
            </div>
          </div>
          
        </div>
      </div>
                        <?php
include "footer.php";
?>